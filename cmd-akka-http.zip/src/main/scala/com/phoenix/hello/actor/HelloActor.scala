package com.phoenix.hello.actor

import akka.actor.Actor
import com.phoenix.hello.domain.{Command, CommandResult}

/**
  * Created by xingzh on 2019/5/19.
  */
class HelloActor extends Actor{
  override def receive: Receive = {
    case Command(name) =>
      sender ! CommandResult("hello",name)
  }
}
