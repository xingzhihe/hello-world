package com.phoenix.hello

import scala.concurrent._
import scala.sys.process._
import ExecutionContext.Implicits.global
import scala.concurrent.duration._

/**
  * Created by xingzh on 2019/5/22.
  */
object TestCMD {
  def main(args: Array[String]): Unit = {
    println("starting...")

    val arrCMD = Array("tasklist", "Find /I \"java\"")

    val dirResult = "tasklist" #| "Find /I \"idea\"" !!;
    val arr = dirResult.split("\r\n").map(_.split("\\s+").apply(1))
    print(dirResult)
    println(arr.mkString("\r\n"))

    val p = "notepad".run
    val f = Future(blocking(p.exitValue()))
    val r = try {
      Await.result(f, Duration(2, SECONDS))
    } catch {
      case _: TimeoutException =>
        println("TimeOut!")
        p.destroy()
        p.exitValue()
    }
    println(r)

    println("stopping...")
  }
}
