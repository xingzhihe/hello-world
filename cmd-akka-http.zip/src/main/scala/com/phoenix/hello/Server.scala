package com.phoenix.hello

import akka.{Done, pattern}
import akka.actor.{ActorSystem, Props}
import akka.pattern.ask

import scala.concurrent.duration._
import akka.http.scaladsl.server.{HttpApp, Route}
import akka.util.Timeout
import com.phoenix.hello.actor.{CommandActor, HelloActor}
import com.phoenix.hello.domain._

import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

/**
  * Created by xingzh on 2019/5/19.
  */
object Server extends HttpApp with JsonSupport {

  implicit val actorSystem = ActorSystem("simple-web")
  lazy val helloActor = actorSystem.actorOf(Props[HelloActor])
  lazy val cmdActor = actorSystem.actorOf(Props[CommandActor])

  implicit val timeout = Timeout(5.seconds)

  override protected def routes: Route = {
    path(""){
      get{
        complete("hello")
      }
    }~
      path("helloDTO"){
        get{
          complete(CommandResult("hello","martin"))
        }
      }~
      (get & path("helloActor")){
        parameter("name"){name=>
          onSuccess(helloActor ? Command(name)){
            case cmdResult:CommandResult=>complete{cmdResult}
          }
        }
      }~
      (get & path("cmd")){
        parameter("args"){args=>
          onSuccess(cmdActor ? Command(args)){
            case cmdResult:CommandResult=>complete{cmdResult}
          }
        }
      }~
      (get & pathPrefix("static")){
        getFromResourceDirectory("static")
      }
  }

  override protected def waitForShutdownSignal(system: ActorSystem)(implicit ec: ExecutionContext): Future[Done] = {
    //pattern.after(5 seconds, actorSystem.scheduler)(Future.successful(Done))
    Future.never
  }

  override protected def postServerShutdown(attempt: Try[Done], system: ActorSystem): Unit = {
    actorSystem.terminate()
    super.postServerShutdown(attempt, system)
  }

  def main(args: Array[String]): Unit = {
    Server.startServer("0.0.0.0",8080,actorSystem)
  }
}
