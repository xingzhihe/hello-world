package com.phoenix.hello.domain

import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport
import spray.json.DefaultJsonProtocol

/**
  * Created by xingzh on 2019/5/19.
  */
case class YourName(name:String)
case class HelloDTO(str:String,name:String)

case class Command(cmd:String)
case class CommandResult(cmd:String, result:String)

trait JsonSupport extends SprayJsonSupport with DefaultJsonProtocol{
  //implicit val helloDTOFormat = jsonFormat2(HelloDTO)
  implicit val cmdResultFormat = jsonFormat2(CommandResult)
}
